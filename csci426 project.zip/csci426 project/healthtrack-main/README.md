# HealthTrack

**CSCI426 — Advanced Web Programming — Project Phase 1**
Lebanese International University

## Project Description

HealthTrack is a personal wellness tracking web application built with **React**.
It lets a user log daily meals, workouts, water intake, and sleep, and see running
totals for the day update instantly. This phase is a frontend-only application —
all data is kept in local component state (no backend/database yet).

## Pages

| Page | Route | Description |
|---|---|---|
| Home | `/` | Landing page with hero section and stat highlights |
| About | `/about` | Project background and approach |
| Features | `/features` | Overview of the four tracked categories |
| My Log | `/log` | **Dynamic page** — add/delete daily activity entries in a live table with running totals |
| Contact | `/contact` | Contact form with controlled inputs |

## Tech Stack

- React (Vite)
- react-router-dom
- Plain CSS (custom design system, no UI framework)

## Folder Structure

```
src/
  assets/
  components/   # NavBar, Footer, PulseDivider (shared UI)
  pages/        # Home, About, Features, Contact, ActivityLog
  styles/       # one .css file per component/page + global.css
  App.jsx
  main.jsx
```

## Setup Instructions

1. Clone the repository:
   ```
   git clone <repo-url>
   cd healthtrack
   ```
2. Install dependencies:
   ```
   npm install
   ```
3. Run the development server:
   ```
   npm run dev
   ```
4. Open the app at `http://localhost:5173`

To build for production:
```
npm run build
```

## Author

Ali — CSCI426 Project Phase 1 (individual submission)
