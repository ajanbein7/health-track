import '../styles/PulseDivider.css';


const PulseDivider = ({ label }) => {
  return (
    <div className="pulse-divider">
      <span className="pulse-divider-line" />
      <svg
        className="pulse-divider-svg"
        viewBox="0 0 400 40"
        preserveAspectRatio="none"
        aria-hidden="true"
      >
        <path
          d="M0 20 H140 L155 4 L170 36 L185 20 H400"
          fill="none"
          stroke="#FF6B4A"
          strokeWidth="2.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>
      {label && <span className="pulse-divider-label">{label}</span>}
      <span className="pulse-divider-line" />
    </div>
  );
};

export default PulseDivider;
