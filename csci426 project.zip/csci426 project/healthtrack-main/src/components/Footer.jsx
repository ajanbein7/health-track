import React from 'react'
import InstagramIcon from "@mui/icons-material/Instagram";
import TwitterIcon from "@mui/icons-material/Twitter";
import GitHubIcon from "@mui/icons-material/GitHub";
import "../styles/Footer.css";

const Footer = () => {
  return (
    <div className="footer">
      <div className="container footer-inner">

        <div className="footer-brand">
          <span className="footer-logo">HealthTrack</span>
          <p className="footer-tagline">Log it daily. See it clearly.</p>
        </div>

        <div className="footer-links">
          <div>
            <h4>Site</h4>
            <a href="/">Home</a>
            <a href="/about">About</a>
            <a href="/features">Features</a>
            <a href="/log">My Log</a>
          </div>

          <div>
            <h4>Get in touch</h4>
            <a href="/contact">Contact</a>
            <a href="mailto:hello@healthtrack.app">hello@healthtrack.app</a>
          </div>
        </div>

        <div className="footer-social">
          <InstagramIcon />
          <TwitterIcon />
          <GitHubIcon />
        </div>

      </div>

      <div className="footer-bottom">
        <p>&copy; {new Date().getFullYear()} HealthTrack</p>
      </div>
    </div>
  )
}

export default Footer