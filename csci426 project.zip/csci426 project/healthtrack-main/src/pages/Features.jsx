import PulseDivider from '../components/PulseDivider';
import '../styles/Features.css';

const features = [
  {
    icon: '🍽️',
    title: 'Meal logging',
    text: 'Record what you eat and roughly how many calories it carries — no barcode scanning required.',
  },
  {
    icon: '🏃',
    title: 'Workout tracking',
    text: 'Log the type and duration of a workout in under ten seconds, right after you finish.',
  },
  {
    icon: '💧',
    title: 'Water intake',
    text: 'Keep a running count of glasses or millilitres so hydration stops being an afterthought.',
  },
  {
    icon: '😴',
    title: 'Sleep entries',
    text: 'Note hours slept alongside everything else, so tired days stop looking like a mystery.',
  },
  {
    icon: '📊',
    title: 'Daily totals',
    text: 'Your log page tallies entries and estimated calories automatically as you add them.',
  },
  {
    icon: '🗂️',
    title: 'One clear table',
    text: 'Every entry lives in a single sortable table you can scan, edit, or remove at a glance.',
  },
];

const Features = () => {
  return (
    <div className="page features">
      <section className="container features-hero">
        <span className="eyebrow">Features</span>
        <h1>Four habits. One log.</h1>
        <p>
          HealthTrack doesn't try to track everything about you — just the four things that
          quietly shape how you feel: what you eat, how you move, how much you drink, and how
          you sleep.
        </p>
      </section>

      <PulseDivider />

      <section className="container features-grid">
        {features.map((f) => (
          <div className="feature-card" key={f.title}>
            <span className="feature-icon">{f.icon}</span>
            <h3>{f.title}</h3>
            <p>{f.text}</p>
          </div>
        ))}
      </section>
    </div>
  );
};

export default Features;
