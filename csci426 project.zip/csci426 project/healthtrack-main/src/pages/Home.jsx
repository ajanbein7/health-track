import { Link } from 'react-router-dom';
import PulseDivider from '../components/PulseDivider';
import '../styles/Home.css';

const stats = [
  { value: '4', unit: 'streams', label: 'Meals, workouts, sleep & water in one log' },
  { value: '<30s', unit: '', label: 'Average time to log an entry' },
  { value: '100%', unit: '', label: 'Your data, stored only in your session' },
];

const Home = () => {
  return (
    <div className="page home">
      <section className="hero container">
        <span className="eyebrow">Personal wellness tracking</span>
        <h1 className="hero-title">
          Your day has a rhythm.
          <br />
          <span className="hero-title-accent">HealthTrack</span> reads it.
        </h1>
        <p className="hero-sub">
          Log your meals, workouts, sleep, and water in seconds — and watch small,
          honest habits add up to a clearer picture of how you actually live.
        </p>
        <div className="hero-actions">
          <Link to="/log" className="btn btn-primary">
            Start logging today
          </Link>
          <Link to="/features" className="btn btn-outline">
            See how it works
          </Link>
        </div>

        <svg className="hero-trace" viewBox="0 0 900 120" preserveAspectRatio="none" aria-hidden="true">
          <path
            d="M0 60 H280 L305 20 L335 100 L360 60 H520 L545 35 L575 85 L600 60 H900"
            fill="none"
            stroke="#FF6B4A"
            strokeWidth="3"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      </section>

      <PulseDivider label="Why it works" />

      <section className="stats container">
        {stats.map((s) => (
          <div className="stat-card" key={s.label}>
            <span className="stat-value">
              {s.value}
              {s.unit && <span className="stat-unit"> {s.unit}</span>}
            </span>
            <p className="stat-label">{s.label}</p>
          </div>
        ))}
      </section>

      <section className="cta-band">
        <div className="container cta-band-inner">
          <div>
            <h2>Ready to see your own rhythm?</h2>
            <p>No sign-up required for this preview — jump straight into your log.</p>
          </div>
          <Link to="/log" className="btn btn-primary">
            Open my log
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Home;
