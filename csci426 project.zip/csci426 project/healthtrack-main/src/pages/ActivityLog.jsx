import { useState } from 'react';
import '../styles/ActivityLog.css';

const CATEGORIES = ['Meal', 'Workout', 'Water', 'Sleep'];


const CALORIE_RATE = {
  Meal: 8,
  Workout: -7, 
  Water: 0,
  Sleep: 0,
};

let nextId = 1;

const ActivityLog = () => {
  const [entries, setEntries] = useState([]);
  const [form, setForm] = useState({
    category: 'Meal',
    detail: '',
    amount: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.detail || !form.amount) return;

    const newEntry = {
      id: nextId++,
      category: form.category,
      detail: form.detail,
      amount: Number(form.amount),
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    entries.push(newEntry);
    setEntries([...entries]);
    setForm({ category: 'Meal', detail: '', amount: '' });
  };

  const handleDelete = (id) => {
    const filtered = entries.filter((entry) => entry.id !== id);
    setEntries(filtered);
  };

  const totalEntries = entries.length;
  const netCalories = entries.reduce(
    (sum, entry) => sum + entry.amount * CALORIE_RATE[entry.category],
    0
  );
  const waterTotal = entries
    .filter((e) => e.category === 'Water')
    .reduce((sum, e) => sum + e.amount, 0);

  return (
    <div className="page activity-log">
      <section className="container log-hero">
        <span className="eyebrow">My log — dynamic page</span>
        <h1>Today at a glance.</h1>
        <p>Log an entry below and watch your daily totals update instantly.</p>
      </section>

      <section className="container log-stats">
        <div className="log-stat">
          <span className="log-stat-value">{totalEntries}</span>
          <span className="log-stat-label">Entries today</span>
        </div>
        <div className="log-stat">
          <span className="log-stat-value">{netCalories}</span>
          <span className="log-stat-label">Net calories (est.)</span>
        </div>
        <div className="log-stat">
          <span className="log-stat-value">{waterTotal}</span>
          <span className="log-stat-label">Water logged (glasses)</span>
        </div>
      </section>

      <section className="container log-body">
        <form className="log-form" onSubmit={handleSubmit}>
          <h2>Add an entry</h2>

          <label>
            Category
            <select name="category" value={form.category} onChange={handleChange}>
              {CATEGORIES.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </label>

          <label>
            Detail
            <input
              type="text"
              name="detail"
              value={form.detail}
              onChange={handleChange}
              placeholder="e.g. Grilled chicken bowl, 5km run, 1 glass"
              required
            />
          </label>

          <label>
            Amount
            <input
              type="number"
              name="amount"
              value={form.amount}
              onChange={handleChange}
              placeholder="e.g. minutes, glasses, hours"
              min="0"
              required
            />
          </label>

          <button type="submit" className="btn btn-primary">
            Add to log
          </button>
        </form>

        <div className="log-table-wrap">
          <h2>Today's entries</h2>

          {entries.length === 0 ? (
            <p className="log-empty">Nothing logged yet — add your first entry to see it here.</p>
          ) : (
            <table className="log-table">
              <thead>
                <tr>
                  <th>Time</th>
                  <th>Category</th>
                  <th>Detail</th>
                  <th>Amount</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {entries.map((entry) => (
                  <tr key={entry.id}>
                    <td>{entry.time}</td>
                    <td>
                      <span className={`tag tag-${entry.category.toLowerCase()}`}>
                        {entry.category}
                      </span>
                    </td>
                    <td>{entry.detail}</td>
                    <td>{entry.amount}</td>
                    <td>
                      <button
                        type="button"
                        className="log-delete"
                        onClick={() => handleDelete(entry.id)}
                        aria-label={`Delete entry: ${entry.detail}`}
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </section>
    </div>
  );
};

export default ActivityLog;
