import PulseDivider from '../components/PulseDivider';
import '../styles/About.css';

const timeline = [
  {
    step: '01',
    title: 'Notice',
    text: "Most people don't lack willpower — they lack visibility into what a normal day actually looks like.",
  },
  {
    step: '02',
    title: 'Log',
    text: 'HealthTrack keeps the input simple: a type, an amount, and a moment in time. Nothing to overthink.',
  },
  {
    step: '03',
    title: 'Understand',
    text: 'Patterns emerge on their own once a week or two of entries sit next to each other.',
  },
];

const About = () => {
  return (
    <div className="page about">
      <section className="container about-hero">
        <span className="eyebrow">About HealthTrack</span>
        <h1>Built for the version of you that skips the spreadsheet.</h1>
        <p className="about-lead">
          HealthTrack is a personal wellness tracker built as a student project for CSCI426 —
          Advanced Web Programming. It focuses on one job: making it effortless to log daily
          activities, meals, and exercise, so the data can speak for itself.
        </p>
      </section>

      <PulseDivider label="How the idea grew" />

      <section className="container timeline">
        {timeline.map((t) => (
          <div className="timeline-item" key={t.step}>
            <span className="timeline-step">{t.step}</span>
            <h3>{t.title}</h3>
            <p>{t.text}</p>
          </div>
        ))}
      </section>

      <section className="container about-mission">
        <div className="about-mission-card">
          <h2>Our approach</h2>
          <p>
            We deliberately kept the interface quiet: one log, a handful of categories, and a
            clear table of what you've entered. No streaks to protect, no guilt-driven
            notifications — just an honest record you can look back on.
          </p>
        </div>
      </section>
    </div>
  );
};

export default About;
