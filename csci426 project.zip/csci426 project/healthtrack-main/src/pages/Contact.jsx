import { useState } from 'react';
import '../styles/Contact.css';

const Contact = () => {
  const [form, setForm] = useState({ name: '', email: '', message: '' });
  const [sent, setSent] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.name || !form.email || !form.message) return;
    setSent(true);
    setForm({ name: '', email: '', message: '' });
  };

  return (
    <div className="page contact">
      <section className="container contact-wrap">
        <div className="contact-intro">
          <span className="eyebrow">Contact</span>
          <h1>Questions, feedback, bug reports.</h1>
          <p>
            Feel free to reach out with anything you noticed, liked, or think should work differently. 
          </p>
          <div className="contact-detail">
            <strong>Email</strong>
            <span>hello@healthtrack.app</span>
          </div>
          <div className="contact-detail">
            <strong>Phone Number</strong>
            <span>81 123 456</span>
          </div>
        </div>

        <form className="contact-form" onSubmit={handleSubmit}>
          <label>
            Name
            <input
              type="text"
              name="name"
              value={form.name}
              onChange={handleChange}
              placeholder="Your name"
              required
            />
          </label>

          <label>
            Email
            <input
              type="email"
              name="email"
              value={form.email}
              onChange={handleChange}
              placeholder="you@example.com"
              required
            />
          </label>

          <label>
            Message
            <textarea
              name="message"
              value={form.message}
              onChange={handleChange}
              placeholder="What's on your mind?"
              rows="5"
              required
            />
          </label>

          <button type="submit" className="btn btn-primary">
            Send message
          </button>

          {sent && <p className="contact-success">Thanks — your message has been noted.</p>}
        </form>
      </section>
    </div>
  );
};

export default Contact;
